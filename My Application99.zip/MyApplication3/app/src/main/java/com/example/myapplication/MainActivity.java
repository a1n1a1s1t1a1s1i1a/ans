package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    EditText etdUS, etdRU;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        etdUS = findViewById(R.id.edtUS);
        etdRU = findViewById(R.id.edtRU);
        etdUS.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                try{
                    Double.parseDouble(s.toString());
                    etdUS.setTextColor(Color.BLUE);
                }
                catch(Exception e){
                    etdUS.setTextColor(Color.RED);

                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
        etdRU.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                try{
                    Double.parseDouble(s.toString());
                    etdRU.setTextColor(Color.BLUE);
                }
                catch(Exception e){
                    etdRU.setTextColor(Color.RED);

                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btnConvert: {
                Double d = Double.parseDouble(etdUS.getText().toString());

                String ans = String.valueOf(d / 70);
                etdRU.setText(ans);
                break;
            }
            case R.id.btnExit: {
                finish();
                break;
            }
            case R.id.btnConvert2: {
                Double d = Double.parseDouble(etdRU.getText().toString());
                d = Math.round(d * 100.00) / 100.00;
                String ans = String.valueOf(d * 70);
                etdUS.setText(ans);
                break;


            }
        }
    }
}